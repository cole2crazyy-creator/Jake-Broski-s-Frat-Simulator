# Frat Simulator — Web Prototype

This is a single-file browser game prototype. It includes:
- Free-roam WASD movement (first/third-person), basic collisions
- Parties, football games, liquor store shifts (3 mini-challenges)
- Aura/Rank/Frats, loyalty, popularity, fights, police busts
- Phone with contacts/messages/events + rizz minigame
- Jersey shop & Frat Bucks, save/load, controller support

## Run locally
1. Unzip this folder.
2. Open a terminal in the folder and run a local server:
   - Python 3: `python3 -m http.server 8000`
3. Visit: http://localhost:8000 and click `index.html`
4. Click the canvas to lock the pointer; use WASD to move.
5. Controls: E=interact, V=first/third, P=phone, J=shop, Esc=pause.

## Deploy (itch.io)
Upload `index.html` as an HTML5 project. Ensure cross-origin modules are allowed or package Three.js locally if needed.
